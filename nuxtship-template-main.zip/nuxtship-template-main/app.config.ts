// app.config.ts
export default defineAppConfig({
  nuxtIcon: {
    class: "",
  },
});
