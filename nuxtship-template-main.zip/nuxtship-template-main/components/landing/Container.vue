<template>
  <div class="max-w-screen-xl mx-auto px-5">
    <slot />
  </div>
</template>
