<template>
  <div
    class="bg-black px-20 py-20 mt-20 mx-auto max-w-5xl rounded-lg flex flex-col items-center text-center"
  >
    <h2 class="text-white text-3xl md:text-6xl">Build faster websites.</h2>
    <p class="text-slate-500 mt-4 text-lg md:text-xl">
      Static or Dynamic, the choice is yours with Nuxt's hybrid rendering modes.
    </p>
    <div class="flex mt-5">
      <LandingLink href="#" styleName="inverted">Get Started</LandingLink>
    </div>
  </div>
</template>
