<template>
  <div class="mt-24">
    <h2 class="text-center text-slate-500">Works with your technologies</h2>
    <div
      class="flex gap-8 md:gap-20 items-center justify-center mt-10 flex-wrap"
    >
      <Icon class="h-8 md:h-14" name="simple-icons:nuxtdotjs" size="48" />
      <Icon class="h-8 md:h-14" name="simple-icons:tailwindcss" size="48" />
      <Icon class="h-8 md:h-14" name="simple-icons:vuedotjs" size="48" />
      <Icon class="h-8 md:h-14" name="simple-icons:html5" size="48" />
      <Icon class="h-8 md:h-12" name="simple-icons:vercel" size="48" />
      <Icon class="h-8 md:h-12" name="simple-icons:netlify" size="48" />
    </div>
  </div>
</template>
